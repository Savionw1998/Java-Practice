
public class Bat extends Mammal {
	public int energy = 300;
	public String Fly() {
		energy -= 50;
		return "Lost 50 energy!";
		}
	public String eatHumans() {
		energy += 25;
		return "Yumm, Gained 25 energy!";
		}
	public String attackTown() {
		energy -= 100;
		return "AAAAAHHHHHHHH!!!";
		}
	public String displayEnergy() {
		return "Energy Level is: " + energy;
		}
}
