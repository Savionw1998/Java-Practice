
public class Mammal {
public int energy = 100;
public String displayEnergy() {
	return "Energy Level is: " + energy;
	}
}
