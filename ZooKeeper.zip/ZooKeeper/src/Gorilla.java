
public class Gorilla extends Mammal {
	public String throwSomething() {
		energy -= 5;
		return "Lost 5 energy!";
		}
	public String eatBananas() {
		energy += 10;
		return "Gained 10 energy!";
		}
	public String climbTree() {
		energy -= 10;
		return "Lost 10 energy!";
		}
}
