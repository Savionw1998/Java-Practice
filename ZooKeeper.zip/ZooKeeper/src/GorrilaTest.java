
public class GorrilaTest extends Mammal {
public static void main(String[] args) {
	Gorilla gorilla1 = new Gorilla();
	gorilla1.throwSomething();
	gorilla1.throwSomething();
	gorilla1.throwSomething();
	gorilla1.eatBananas();
	gorilla1.eatBananas();
	gorilla1.climbTree();
	String x = gorilla1.displayEnergy();
	System.out.println(x);

}
}
