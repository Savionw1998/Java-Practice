
public class BatTest extends Mammal{
public static void main(String[] args) {
		Bat bat1 = new Bat();
		bat1.attackTown();
		bat1.attackTown();
		bat1.attackTown();
		bat1.eatHumans();
		bat1.eatHumans();
		bat1.Fly();
		bat1.Fly();
		String x = bat1.displayEnergy();
		System.out.println(x);
	}
}
