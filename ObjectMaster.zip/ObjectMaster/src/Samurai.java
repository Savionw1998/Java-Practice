
public class Samurai extends Human {
public int health = 200;
public String deathBlow(Human human) {
	human.health = 0;
	this.health /= 2;
	return "Human's Dead!";
}
public Integer meditate() {
	int x = this.health;
	int y = this.health/2;
	int sum = x + y;
	return sum;
}
}
