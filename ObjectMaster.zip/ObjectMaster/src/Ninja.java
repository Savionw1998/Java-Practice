
public class Ninja extends Human{
public int stealth = 10;
public String steal(Human human) {
	human.health -= this.stealth;
	this.health = this.stealth;
	return "Robbing!";
}
public String ranAway() {
	this.health -= 10;
	return "Running!";
}
}
