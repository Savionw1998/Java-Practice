public class Human {
	public int health;
	public int stealth;
	public int intelligence;
	public int strength;
    public Human() {
        this.health = 100;
        this.stealth = 3;
        this.intelligence = 3;
        this.strength = 3;
    }
	public String attack(Human human) {
		human.health -= this.strength;
		return "Hit!!";
	}
	public String displayHealth() {
		int x = this.health;
		return "Your health is: " + x;
	}
}
