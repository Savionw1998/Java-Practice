
public class HumanTest {
	public static void main(String[] args) {
		Human human1 = new Human();
		Human human2 = new Human();
		human1.attack(human2);
		String x = human1.displayHealth();
		String y = human2.displayHealth();
		String z = "Human 1 " + x + " Human 2 " + y; 
		System.out.println(z);

	}
}