
public class Wizard extends Human {
public int health = 50;
public int intelligence = 8;
public String heal(Human human) {
	human.health = this.intelligence;
	return "Healing Human!";
}
public String fireball(Human human) {
	human.health -= this.intelligence*3;
	return "Flaming Human!";
}
}
