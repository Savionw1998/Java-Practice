package com.main.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.main.models.Person;
import com.main.repositories.PersonRepository;

@Service
public class PersonService {
public static PersonRepository PersonRepository;
    
    public PersonService(PersonRepository PersonRepository) {
        PersonService.PersonRepository = PersonRepository;
    }

    public static List<Person> allPersons() {
        return PersonRepository.findAll();
    }

    public static Person create(Person b) {
        return PersonRepository.save(b);
    }

    public static Person findPerson(Long id) {
        Optional<Person> optionalPerson = PersonRepository.findById(id);
        if(optionalPerson.isPresent()) {
            return optionalPerson.get();
        } else {
            return null;
        }
    }
    public static Person update(Person Person) {
    	return PersonRepository.save(Person);
    }
    public void deletePerson(Long id) {
        PersonRepository.deleteById(id);
    }
}
