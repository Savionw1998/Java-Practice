package com.main.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.main.models.License;
import com.main.repositories.LicenseRepository;

@Service
public class LicenseService {
    public static LicenseRepository LicenseRepository;
    
    public LicenseService(LicenseRepository LicenseRepository) {
        LicenseService.LicenseRepository = LicenseRepository;
    }

    public static List<License> allLicenses() {
        return LicenseRepository.findAll();
    }

    public static License create(License b) {
        return LicenseRepository.save(b);
    }

    public static License findLicense(Long id) {
        Optional<License> optionalLang = LicenseRepository.findById(id);
        if(optionalLang.isPresent()) {
            return optionalLang.get();
        } else {
            return null;
        }
    }
    public static License update(License License) {
    	return LicenseRepository.save(License);
    }
    public void deleteLicense(Long id) {
        LicenseRepository.deleteById(id);
    }
}
