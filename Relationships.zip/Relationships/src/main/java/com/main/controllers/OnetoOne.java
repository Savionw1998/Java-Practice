package com.main.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.main.models.License;
import com.main.models.Person;
import com.main.services.LicenseService;
import com.main.services.PersonService;

@Controller
public class OnetoOne {

	@RequestMapping("/")
    public String home() {
    	return "Home.jsp";
    }
	@RequestMapping("/person/{id}")
	public String show(@PathVariable("id") Long id, Model model) {
		Person Person = PersonService.findPerson(id);
		model.addAttribute("Person", Person);
		return "ShowPerson.jsp";
	}
    @RequestMapping("/person/addperson")
    public String addPerson(@ModelAttribute("person") Person person) {
    	return "AddPersonPage.jsp";
    }
	@PostMapping(value="/person/add")
	public String create(@Valid @ModelAttribute("person") Person person, BindingResult result) {
		if(result.hasErrors()) {
            return "AddPersonPage.jsp";
        } else {
        	PersonService.create(person);
        	return "redirect:/";
        }
	}
	@RequestMapping("/license")
	public String addLicensePage(@ModelAttribute("license") License license, Model model) {
    	List<Person> person = PersonService.allPersons();
		model.addAttribute("person", person);
		return "AddLicensePage.jsp";
	}
	@PostMapping(value="/license/add")
	public String createLicense(@Valid @ModelAttribute("license") License license, BindingResult result) {
		if(result.hasErrors()) {
			return "AddLicensePage.jsp";
		} else {
			LicenseService.create(license);
			return "redirect:/";
		}
	}
}
