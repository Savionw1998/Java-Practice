package com.myfirst.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.myfirst.models.Language;
import com.myfirst.Repos.LanguageRepository;

@Service
public class LanguageService {
    public static LanguageRepository languageRepository;
    
    public LanguageService(LanguageRepository languageRepository) {
        LanguageService.languageRepository = languageRepository;
    }

    public static List<Language> allLanguages() {
        return languageRepository.findAll();
    }

    public static Language create(Language b) {
        return languageRepository.save(b);
    }

    public static Language findLanguage(Long id) {
        Optional<Language> optionalLang = languageRepository.findById(id);
        if(optionalLang.isPresent()) {
            return optionalLang.get();
        } else {
            return null;
        }
    }
    public static Language update(Language language) {
    	return languageRepository.save(language);
    }
    public void deleteLanguage(Long id) {
        languageRepository.deleteById(id);
    }
}