package com.myfirst.controllers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.myfirst.models.Language;
import com.myfirst.services.LanguageService;

@Controller
public class LanguageController {
    
	@RequestMapping("/")
    public String home(Model model) {
    	List<Language> language = LanguageService.allLanguages();
        model.addAttribute("language", language);
    	return "Dashboard.jsp";
    }
	@RequestMapping(value="/addlanguage", method=RequestMethod.POST)
    public String create(@RequestParam(value="name") String name, @RequestParam(value="creator") String creator, @RequestParam(value="version") Integer version) {
		Language language = new Language(name, creator, version);
		LanguageService.create(language);
    	return "redirect:/";
    }
    @RequestMapping("/dashboard/edit/{id}")
    public String edit(@PathVariable("id") Long id, Model model) {
        Language language = LanguageService.findLanguage(id);
        model.addAttribute("language", language);
        return "Edit.jsp";
    }
    @RequestMapping(value="/dasboard/{id}/edit", method=RequestMethod.PUT)
    public String update(@PathVariable(value="id") Long id, @RequestParam(value="name") String name, @RequestParam(value="creator") String creator, @RequestParam(value="version") Integer version) {        
        Language lang = LanguageService.findLanguage(id);
        lang.setName(name);
        lang.setCreator(creator);
        lang.setVersion(version);
        LanguageService.update(lang);
    	return "redirect:/";
    }
    @RequestMapping("/dashboard/show/{id}")
    public String home(@PathVariable(value="id") Long id, Model model) {
        Language lang = LanguageService.findLanguage(id);
        model.addAttribute("language", lang);
        return "Show.jsp";
    }
}
