
public class CaculatorTest {
	public static void main(String[] args) {
		Calculator calculator = new Calculator();
		
		calculator.setOperandOne(10.5);

		calculator.setOperation('+');

		calculator.setOperandTwo(5.2);

		calculator.performOperation();

		String y = calculator.getResults();
		
		System.out.println(y);
	}
}
