
public class Calculator {
	public Double Operand1 = 0.0;
	public Double Operand2 = 0.0;
	public Character Operand3 = 0;
	public Double Results = 0.0;

    public Double setOperandOne(Double a){
    	Operand1 = a;
    	return Operand1;
    	}
    public Double setOperandTwo(Double b){
    	Operand2 = b;
    	return Operand2;
    	}
    public Character setOperation(char c){
    	Operand3 = c;
    	return Operand3;
    	}
    public Double getOperandOne() {
    	return Operand1;
    }
    public Double getOperandTwo() {
    	return Operand2;
    }
    public Character getOperandThree() {
    	return Operand3;
    }
    public String getResults(){
    	Double results = Results;
    	String x = "Your results are: "+ results;
    	return x;
    }
    public void performOperation(){
    	Double operand1 = Operand1;
    	Double operand2 = Operand2;
    	Character operand3 = Operand3;
    	if (operand3 == '+') {
    			Results = operand1 + operand2;
    		}else if (operand3 == '-') {
    			Results = operand1 - operand2;
    		}else if (operand3 == '*') {
    			Results = operand1 * operand2;
    		}else if (operand3 == '/') {
    			Results = operand1 / operand2;
    		}
    }
}