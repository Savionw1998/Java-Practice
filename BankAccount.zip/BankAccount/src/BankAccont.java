
public class BankAccont {
public static int numberofaccounts = 0;
public static int currentbanktotal = 0;
public Integer accountnumber = 0;
public Double checkingbalance = 0.0;
public Double savingsbalance = 0.0;

public String BankAccount() {
	this.giveAccountNumber();
	this.checkingbalance = 0.0;
	this.savingsbalance = 0.0;
	String x = "Your account number is: " + this.accountnumber + " You have "
			+ this.checkingbalance + " in your checking and " + this.savingsbalance + " in your savings!";
	numberofaccounts++;
	return x;
}
private Integer giveAccountNumber(){
	int randomNum = (int)(Math.random() * 1234567890);
	return randomNum;
}
public Double getCheckingInfo() {
	Double x = this.checkingbalance;
	return x;
}
public Double getSavingsInfo() {
	Double x = this.savingsbalance;
	return x;
}
public String depositChecking(int deposit) {
	this.checkingbalance += deposit;
	currentbanktotal += deposit;
	return "Successful Deposit!!";
}
public String depositSavings(int deposit) {
	this.savingsbalance += deposit;
	currentbanktotal += deposit;
	return "Successful Deposit!!";
}
public String withdrawSavings(int withdraw) {
	if (withdraw < this.savingsbalance) {
		this.savingsbalance -= withdraw;
		currentbanktotal -= withdraw;
	}
	else {
		System.out.println("Insufficient Funds.");
	}
	return "Successful Withdraw!!";
}
public String withdrawChecking(int withdraw) {
	if (withdraw < this.checkingbalance) {
		this.checkingbalance -= withdraw;
		currentbanktotal -= withdraw;
	}
	else {
		return "Insufficient Funds.";
	}
	return "Successful Withdraw!!";
}
public String netWorth() {
	Double x = this.checkingbalance + this.savingsbalance;
	String y = "Your networth is: " + x;
	return y;
}
}
