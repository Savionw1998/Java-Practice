
public class BankAccountTest extends BankAccont {
	public static void main(String[] args) {
		BankAccont Account1 = new BankAccont();
		BankAccont Account2 = new BankAccont();
		BankAccont Account3 = new BankAccont();
		Account1.depositChecking(1500);
		Double x = Account1.checkingbalance;
		int y = currentbanktotal;
		System.out.println(y);

		
	}
}
