package com.myfirst;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import java.time.LocalTime;
import java.time.LocalDate;

@Controller
public class HomeController {
@RequestMapping("")
	public String Home1() {
	return "Index.jsp";
	}
@RequestMapping("time")
	public String Home2(Model model) {
    LocalTime myObj = LocalTime.now();
    model.addAttribute("time", myObj);	
    return "Time.jsp";
	}
@RequestMapping("date")
public String Home1(Model model) {
    LocalDate myObj = LocalDate.now();
    model.addAttribute("date", myObj);
	return "Date.jsp";
}
}
