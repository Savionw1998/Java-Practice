package com.myfirst;

import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CountController {
	@RequestMapping("/")
	public String HomePage(Model model, HttpSession session ) {
		Integer x = (Integer) session.getAttribute("count");
		if (x == null) {
			x = 1;
		} else {
			x +=1;
		}
		session.setAttribute("count", x);
		return "Home.jsp";
	}
	@RequestMapping("/counter")
	public String CountPage(Model model, HttpSession session) {
		Integer x = (Integer) session.getAttribute("count");
		if (x == null) {
			x = 0;
		} 
		model.addAttribute("counter", x);
		return "Counter.jsp";
	}
}
