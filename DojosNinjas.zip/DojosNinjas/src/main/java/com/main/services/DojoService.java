package com.main.services;

import java.util.List;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.stereotype.Service;

import com.main.models.Dojo;
import com.main.models.Ninja;
import com.main.repositories.DojoRepo;
import com.main.repositories.NinjaRepo;

@Service
public class DojoService {
public static DojoRepo DojoRepo;
    
    public DojoService(DojoRepo DojoRepo) {
        DojoService.DojoRepo = DojoRepo;
    }

    public static List<Dojo> allDojos() {
        return DojoRepo.findAll();
    }

    public static Dojo create(Dojo b) {
        return DojoRepo.save(b);
    }
//    public Ninja create(@Valid Ninja ninja) {
//    	return NinjaRepo.save(ninja);
//    }

    public static Dojo findDojo(Long id) {
        Optional<Dojo> optionalLang = DojoRepo.findById(id);
        if(optionalLang.isPresent()) {
            return optionalLang.get();
        } else {
            return null;
        }
    }
    public static Dojo update(Dojo Dojo) {
    	return DojoRepo.save(Dojo);
    }
    public void deleteDojo(Long id) {
        DojoRepo.deleteById(id);
    }

	public static void addNinja(Ninja ninja) {
			NinjaRepo.save(ninja);
	}
}
