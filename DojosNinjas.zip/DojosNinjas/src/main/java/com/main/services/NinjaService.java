package com.main.services;

import java.util.List;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.main.models.Ninja;
import com.main.repositories.NinjaRepo;

@Service
public class NinjaService {
public static NinjaRepo NinjaRepo;
    
    public NinjaService(NinjaRepo NinjaRepo) {
        NinjaService.NinjaRepo = NinjaRepo;
    }

    public static List<Ninja> allNinjas() {
        return NinjaRepo.findAll();
    }

    public static Ninja create(Ninja b) {
        return NinjaRepo.save(b);
    }

    public static Ninja findNinja(Long id) {
        Optional<Ninja> optionalLang = NinjaRepo.findById(id);
        if(optionalLang.isPresent()) {
            return optionalLang.get();
        } else {
            return null;
        }
    }
    public static Ninja update(Ninja Ninja) {
    	return NinjaRepo.save(Ninja);
    }
    public void deleteNinja(Long id) {
        NinjaRepo.deleteById(id);
    }
}
