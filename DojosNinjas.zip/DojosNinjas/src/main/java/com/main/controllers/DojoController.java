package com.main.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.main.models.Dojo;
import com.main.models.Ninja;

import com.main.services.DojoService;
import com.main.services.NinjaService;

@Controller
public class DojoController {
	@RequestMapping("/")
	public String home(Model model) {
		List<Dojo> dojo = DojoService.allDojos();
		model.addAttribute("dojo", dojo);
		return "Home.jsp";
	}
	@RequestMapping("/adddojo")
    public String AddDojoPage() {
    	return "AddDojoPage.jsp";
    }
	@RequestMapping("/addninja")
    public String AddNinjaPage(Model model) {
		List<Dojo> dojo = DojoService.allDojos();
		model.addAttribute("dojo", dojo);
    	return "AddNinja.jsp";
    }
	@RequestMapping(value="/dojo/new", method=RequestMethod.POST)
    public String createDojo(@RequestParam(value="name") String name) {
		Dojo dojo = new Dojo(name);
		DojoService.create(dojo);
    	return "redirect:/";
    }
	@RequestMapping("/ninja/new")
	public String createNinja(Model model) {
		List<Dojo> dojo = DojoService.allDojos();
		model.addAttribute("dojo", dojo);
		model.addAttribute("ninja", new Ninja());
		return "AddNinja.jsp";
	}
	@PostMapping("/ninja/new")
	public String createNinja(@Valid @ModelAttribute("ninja") Ninja ninja, BindingResult result) {

	}
}
