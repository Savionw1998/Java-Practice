package com.myfirst;

import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class SurveyController {
	@RequestMapping("")
	public String homepage() {
		return "Survey.jsp";
	}
	@RequestMapping(value="/submit_results", method=RequestMethod.POST)
	public String submit(@RequestParam(value="name") String name, 
	    				 @RequestParam(value="location") String location,
						 @RequestParam(value="favorite_language") String favorite_language,
						 @RequestParam(value="comment") String comment, Model model, HttpSession session) {
		
		session.setAttribute("name", name);
		session.setAttribute("location", location);
		session.setAttribute("favorite_language", favorite_language);
		session.setAttribute("comment", comment);
		return "redirect:/results";
	}
	@RequestMapping("/results")
	public String resultspage(Model model, HttpSession session) {
		session.getAttribute("name");
		session.getAttribute("location");
		session.getAttribute("Favorite_language");
		session.getAttribute("comment");
		return "Results.jsp";
	}
    @RequestMapping("/createError")
    public String flashMessages(RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("error", "A test error!");
        return "redirect:/";
    }
}
