package com.myfirst.models;

public class Models {

}
